<?php

return [
    'theme' => 'standart',
    'paginate' => 6,
    'apartments' => [
        'image' => [
            'width' => 1000,
            'dir' => 'apartments_img/',
        ],
        'user_count_create' => 5
    ]
];