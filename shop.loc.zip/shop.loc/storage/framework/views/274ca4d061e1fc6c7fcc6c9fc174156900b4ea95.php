<?php if($apartment): ?>
    <div class="container">
        <h1>
            <?php echo e($apartment->title); ?>

        </h1>
        <div class="col-md-6">

            <?php if($apartment->img): ?>
                <?php $__currentLoopData = $apartment->img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('apartments_img/'. $apartment->alias . '/' . $img)); ?>"
                         alt="" title=""
                         class="property_img"/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <img src="/<?php echo e(config('settings.theme') . "/img/no_image.png"); ?>" alt="no_image" class="property_img"/>
            <?php endif; ?>
        </div>
        <div class="col-md-5">
            <h4 style="margin-top: 0px;">$<?php echo e($apartment->price); ?></h4>
            <form action="<?php echo e(route("book.create", ['alias' => $apartment->alias])); ?>" method="post">
                <div class="input-daterange input-group" id="datepicker">
                    <input type="text" class="input-sm form-control" name="book_start">
                    <span class="input-group-addon">до</span>
                    <input type="text" class="input-sm form-control" name="book_end">
                </div>
                <input type="submit" class="btn btn-success" value="Book">
                <?php echo csrf_field(); ?>
            </form>
            <hr>

        </div>

        <div class="col-md-9">
            <h6><?php echo e($apartment->text); ?></h6>
            <?php if($comforts): ?>
                <ul class="list-group">
                    <li class="list-group-item active">Удобства</li>
                    <?php $__currentLoopData = $comforts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comfort): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"><?php echo e($comfort->com_name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>

    </div>
<?php endif; ?>

<script>
    $(document).ready(function () {

        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();

        sd = new Date(yyyy + '-' + mm + '-' + dd);

        tomorrow = parseInt(dd) + 1 + '-' + mm + '-' + yyyy;

        var enabledDates = <?php echo json_encode($dates); ?>;
        var userBooks = <?php echo json_encode($userBooks); ?>;
        var pattern = /(\d{2})\-(\d{2})\-(\d{4})/;

        $('#datepicker').datepicker({
            startDate: today,
            format: 'dd-mm-yyyy',
            language: 'ru',
            clearBtn: true,
            enableOnReadonly: true,
            datesDisabled: enabledDates
        });

        for (var i = 0; i < enabledDates.length; i++) {
            if ((new Date(enabledDates[i].replace(pattern, '$3-$2-$1'))).getTime() == sd.getTime()) {
                sd = new Date(sd.setDate(sd.getDate() + 1));

            }
        }

        $(".form-control").on('click', function (event) {
            var date;
            for (var i = 0; i < userBooks.length; i++) {
                date = (new Date(userBooks[i].replace(pattern, '$3-$2-$1'))).getTime();
                $("td[data-date=" + (new Date(userBooks[i].replace(pattern, '$3-$2-$1'))).getTime() + "]").addClass('today').attr('tooltip', 'It is your book');
            }
        });

        $('input[name=book_start]').datepicker('setDates', sd);


    });
</script>


