<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo e(isset($title) ? $title : 'Booking'); ?></title>
    <meta charset="utf-8">

    <meta name="description" content="<?php echo e(isset($meta_desc) ? $meta_desc : 'Book apartment for your vacation.'); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(config('settings.theme') . '/css/reset.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(config('settings.theme') . '/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(config('settings.theme') . '/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(config('settings.theme') . '/css/bootstrap-datepicker3.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(config('settings.theme') . '/css/jquery.sTags.min.css')); ?>">
    
    <script type="text/javascript" src="<?php echo e(asset(config('settings.theme') . '/js/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset(config('settings.theme') . '/js/bootstrap-datepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset(config('settings.theme') . '/js/bootstrap-datepicker.ru.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset(config('settings.theme') . '/js/jquery.sTags.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset(config('settings.theme') . '/js/main.js')); ?>"></script>
</head>
<body>

<section class="hero">

    <header>
        <div class="wrapper">
            <a href="/"><img src="<?php echo e(asset(config('settings.theme') . '/img/logo.png')); ?>" class="logo" alt="" titl=""/></a>
            <a href="/" class="hamburger"></a>
            <nav>
                <?php echo $__env->yieldContent('navigation'); ?>

                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                    <a class="login_btn" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?> (<?php echo e(Auth::user()->name); ?>)
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>

                    <a href="<?php echo e(url('/cabinet/book')); ?>" class="login_btn">My Books</a>
                    <a href="<?php echo e(url('/cabinet')); ?>" class="login_btn">Home</a>
                <?php else: ?>
                    <a href="<?php echo e(route('register')); ?>" class="login_btn">Register</a>
                    <a href="<?php echo e(route('login')); ?>" class="login_btn">Login</a>
                    <?php endif; ?>

                <?php endif; ?>

            </nav>
        </div>
    </header>

</section>

<div class="container">
    <div class="row">
        <div class="col-md-12" style="padding: 5px;">

            <?php if(count($errors) > 0): ?>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <p><?php echo e($error); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-warning">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
</div>

<?php echo $__env->yieldContent('footer'); ?>

</body>
</html>