<table class="table table-bordered">
    <thead>
    <tr>
        <th>Book start</th>
        <th>Book end</th>
        <th>Book username</th>
    </tr>
    </thead>
    <tbody>
    <?php if($books): ?>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(date('d-m-Y', strtotime($book->book_start))); ?></td>
                <td><?php echo e(date('d-m-Y', strtotime($book->book_end))); ?></td>
                <td><?php echo e($book->user['name'] ? $book->user['name'] : 'Null'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="3" style="text-align: center">Empty</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>