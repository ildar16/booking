<section class="listings">
    <div class="wrapper">
        <?php if($empty_apartments): ?>
            <ul class="properties_list">
                <?php $__currentLoopData = $empty_apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>

                        <a href="/apart/<?php echo e($apartment->alias); ?>">
                            <img src="<?php echo e(asset('apartments_img/'. $apartment->alias . '/' . $apartment->img[0])); ?>"
                                 alt="" title="" class="property_img"/>
                        </a>
                        <span class="price">$<?php echo e($apartment->price); ?></span>
                        <div class="property_details">
                            <h1>
                                <a href="<?php echo e($apartment->alias); ?>"><?php echo e($apartment->title); ?></a>
                            </h1>
                            <h2><?php echo e($apartment->desc); ?></h2>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
                
            
        <?php else: ?>
            <h1>Пусто ...</h1>
        <?php endif; ?>

    </div>
</section>