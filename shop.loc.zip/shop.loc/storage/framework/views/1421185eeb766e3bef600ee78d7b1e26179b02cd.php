<?php $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li style="cursor: pointer;">
        <?php if($apartment->img): ?>
            <a href="/apart/<?php echo e($apartment->alias); ?>">
                <img src="<?php echo e(asset('apartments_img/'. $apartment->alias . '/' . $apartment->img[0])); ?>"
                     alt="" class="property_img"/>
            </a>
            <?php else: ?>
            <a href="/apart/<?php echo e($apartment->alias); ?>">
                <img src="/<?php echo e(config('settings.theme') . "/img/no_image.png"); ?>"
                     alt="" class="property_img"/>
            </a>
        <?php endif; ?>
        <span class="price">$<?php echo e($apartment->price); ?></span>
            <div class="property_details">
                <h1>
                    <a href="<?php echo e($apartment->alias); ?>"><?php echo e($apartment->title); ?></a>
                </h1>
                <h2>Square: <?php echo e($apartment->square); ?> м2</h2>
                <h2>Room: <?php echo e($apartment->rooms); ?></h2>
            </div>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

