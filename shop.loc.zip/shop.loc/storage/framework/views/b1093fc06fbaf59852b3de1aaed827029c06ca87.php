<?php if(isset($menu)): ?>
    <div class="menu classic">
        <ul id="nav" class="menu">
            <?php echo $__env->make(config('settings.theme').'.blocks.customMenuItems',['items'=>$menu->roots()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </ul>
    </div>
<?php endif; ?>
