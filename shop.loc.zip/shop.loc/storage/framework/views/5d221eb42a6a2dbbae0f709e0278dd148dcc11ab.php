<div class="container">
    <div class="col-md-12" style="padding: 10px">

        

        <table class="table table-bordered" style="text-align: center;">
            <thead>
            <tr>
                <th style="text-align: center;">ID</th>
                <th style="text-align: center;">Apart name</th>
                <th style="text-align: center;">User name
                    <form action="<?php echo e(route('admin.filter')); ?>">
                        <input type="text" name="username">
                        <button>search</button>
                    </form>
                </th>
                <th style="text-align: center;">Price</th>
                <th style="text-align: center;">Rooms</th>
                <th style="text-align: center;">All books</th>
                <th style="text-align: center;">Actual books</th>
                <th style="text-align: center;">Status</th>
                <th style="text-align: center;">Action</th>
            </tr>
            </thead>
            <tbody>

            <?php if($apartments): ?>
                <?php ($i = 0); ?>
                <?php $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($apartment->id); ?></td>
                        <td>
                            <?php echo e($apartment->title); ?>

                        </td>
                        <td>
                            <?php echo e($apartment->user->name); ?>

                        </td>
                        <td><?php echo e($apartment->price); ?></td>
                        <td><?php echo e($apartment->rooms); ?></td>
                        <td><?php echo e(count($apartment->book)); ?></td>
                        <td>
                            <?php $__currentLoopData = $apartment->book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Carbon\Carbon::now()->lte(Carbon\Carbon::parse($book->book_end))): ?>
                                    <?php ($i = $i + 1); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($i); ?>

                            <?php ($i = 0); ?>
                        </td>
                        <td>
                            <div class="form-group">
                                <select class="form-control apartment-status" name="status" data-alias="<?php echo e($apartment->alias); ?>">
                                    <option value="0" <?php echo e($apartment->status == 0 ? 'selected' : ''); ?>>Pending</option>
                                    <option value="1" <?php echo e($apartment->status == 1 ? 'selected' : ''); ?>>Approved</option>
                                    <option value="2" <?php echo e($apartment->status == 2 ? 'selected' : ''); ?>>Rejected</option>
                                    <option value="3" <?php echo e($apartment->status == 3 ? 'selected' : ''); ?>>Postponed</option>
                                </select>
                            </div>
                        </td>
                        <td style="width: 255px;">
                            <a href="<?php echo e(route("admin.apartment.show", ['apartment' => $apartment->alias])); ?>"
                               class="btn btn-primary" style="display: inline-block;">Show books</a>
                            <a href="<?php echo e(route("admin.apartment.edit", ['apartment' => $apartment->alias])); ?>"
                               class="btn btn-success" style="display: inline-block;">Edit</a>
                            <form action="<?php echo e(route("admin.apartment.destroy", ['apartment' => $apartment->alias])); ?>"
                                  method="post" style="display: inline-block;">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>

    </div>
    <div style="text-align: center">
        
    </div>
</div>

<script>
    $('.apartment-status').change(function() {
        var apart = $(this).attr('data-alias');
        var status = $(this).val();
        var select = $(this);

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type:'POST',
            async:true,
            beforeSend: function() {
                select.css('background-color', '#eee');
            },
            complete: function() {
                select.css('background-color', 'white');
            },
            url:'/admin_area/apartment/ups/' + apart,
            data:{status: status}
        });
    });
</script>
