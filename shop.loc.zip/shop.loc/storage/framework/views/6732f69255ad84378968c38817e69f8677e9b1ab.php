<?php if($menu): ?>
    <ul id="nav">
        <?php echo $__env->make(config('settings.theme').'.elements.customMenuItems',['items'=>$menu->roots()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </ul>
<?php endif; ?>
