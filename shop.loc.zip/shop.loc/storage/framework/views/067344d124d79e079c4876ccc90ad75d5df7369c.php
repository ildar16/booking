<div class="container">
    <div class="col-md-12" style="padding: 10px">

        

        <table class="table table-bordered" style="text-align: center;">
            <thead>
            <tr>
                <th style="text-align: center;">ID</th>
                <th style="text-align: center;">User name</th>
                <th style="text-align: center;">Email</th>
                <th style="text-align: center;">Status</th>
                <th style="text-align: center;">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php if(!$users->isEmpty()): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td>
                            <?php echo e($user->name); ?>

                        </td>
                        <td><?php echo e($user->email); ?></td>

                        <td>
                            <div class="form-group">
                                <select class="form-control user-status" name="status" data-id="<?php echo e($user->id); ?>">
                                    <option value="0" <?php echo e($user->status == 0 ? 'selected' : ''); ?>>Banned</option>
                                    <option value="1" <?php echo e($user->status == 1 ? 'selected' : ''); ?>>Active</option>
                                </select>
                            </div>
                        </td>

                        <td style="width: 255px;">
                            <form action="<?php echo e(route("admin.apartment.destroy", ['apartment' => $user->id])); ?>"
                                  method="post" style="display: inline-block;">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
