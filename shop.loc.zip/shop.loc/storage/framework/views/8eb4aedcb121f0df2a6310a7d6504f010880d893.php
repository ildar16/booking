<div class="container">
    <div class="col-md-12" style="padding: 10px">

        <a href="<?php echo e(route("apartment.create")); ?>" class="btn btn-primary">Create apartment</a>

        <table class="table table-bordered" style="text-align: center;">
            <thead>
            <tr>
                <th style="text-align: center;">№</th>
                <th style="text-align: center;">Apart name</th>
                <th style="text-align: center;">Price</th>
                <th style="text-align: center;">Rooms</th>
                <th style="text-align: center;">All books</th>
                <th style="text-align: center;">Actual books</th>
                <th style="text-align: center;">Status</th>
                <th style="text-align: center;">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php if(!$apartments->isEmpty()): ?>
                <?php ($i = 0); ?>
                <?php $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td>
                            <?php echo e($apartment->title); ?>

                        </td>
                        <td><?php echo e($apartment->price); ?></td>
                        <td><?php echo e($apartment->rooms); ?></td>
                        <td><?php echo e(count($apartment->book)); ?></td>
                        <td>
                            <?php $__currentLoopData = $apartment->book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Carbon\Carbon::now()->lte(Carbon\Carbon::parse($book->book_end))): ?>
                                    <?php ($i = $i + 1); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($i); ?>

                            <?php ($i = 0); ?>
                        </td>
                        <td>
                            <?php if($apartment->status == 0): ?>
                                <span class="label label-primary">Pending</span>
                            <?php elseif($apartment->status == 1): ?>
                                <span class="label label-success">Approved</span>
                            <?php elseif($apartment->status == 2): ?>
                                <span class="label label-danger">Rejected</span>
                            <?php else: ?>
                                <span class="label label-info">Postponed</span>
                            <?php endif; ?>
                        </td>
                        <td style="width: 255px;">
                            <a href="<?php echo e(route("apartment.show", ['apartment' => $apartment->alias])); ?>" class="btn btn-primary" style="display: inline-block;">Show books</a>
                            <a href="<?php echo e(route("apartment.edit", ['apartment' => $apartment->alias])); ?>" class="btn btn-success" style="display: inline-block;">Edit</a>
                            <form action="<?php echo e(route("apartment.destroy", ['apartment' => $apartment->alias])); ?>" method="post" style="display: inline-block;">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
