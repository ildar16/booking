<section class="listings">
    <div class="wrapper">
        <?php if($apartments): ?>
            <ul class="properties_list" id="post-data">
                <?php echo $__env->make('standart.elements.data', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ul>

            <div class="more_listing">
                <span style="cursor: pointer;" class="more_listing_btn">View More Listings</span>
            </div>

            <div class="ajax-load text-center" style="display:none">
                <p><img src="http://demo.itsolutionstuff.com/plugin/loader.gif">Loading More post</p>
            </div>
        <?php endif; ?>

    </div>
</section>
