<form action="<?php echo e(route("apartment.update", ['cabinet' => $apartment->alias])); ?>" method="post"
      enctype="multipart/form-data">

    <div class="form-group">
        <label>Apartment Name</label>
        <input type="text" class="form-control" name="title" placeholder="Apartment Name"
               value="<?php echo e($apartment->title); ?>">
    </div>

    <div class="form-group">
        <label>Alias</label>
        <input type="text" class="form-control" name="alias" id="alias" placeholder="Alias"
               value="<?php echo e($apartment->alias); ?>" readonly>
    </div>

    <div class="form-group">
        <label>Price</label>
        <input type="number" class="form-control" name="price" placeholder="Price" value="<?php echo e($apartment->price); ?>">
    </div>

    <div class="form-group">
        <label>Description</label>
        <input type="text" class="form-control" name="description" placeholder="Description"
               value="<?php echo e($apartment->description); ?>">
    </div>

    <div class="form-group">
        <label>Rooms</label>
        <select class="form-control" name="rooms">
            <option value="1" <?php echo e($apartment->rooms == 1 ? "selected" : ''); ?>>One room</option>
            <option value="2" <?php echo e($apartment->rooms == 2 ? "selected" : ''); ?>>Two rooms</option>
            <option value="3" <?php echo e($apartment->rooms == 3 ? "selected" : ''); ?>>Three rooms</option>
            <option value="4" <?php echo e($apartment->rooms == 4 ? "selected" : ''); ?>>Four rooms</option>
            <option value="5" <?php echo e($apartment->rooms == 5 ? "selected" : ''); ?>>Five rooms</option>
        </select>
    </div>

    <div class="form-group">
        <label>Images</label>
        <input type="file" class="form-control" id="images" name="img[]" placeholder="Images" multiple="multiple">
    </div>

    <ul id="image-list">
        <?php if($apartment->img): ?>
            <?php $__currentLoopData = $apartment->img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-name="<?php echo e($img); ?>" class="list-group-item">
                    <span class="close"></span>
                    <img src="<?php echo e(asset('apartments_img/' . $apartment->alias . '/' . $img)); ?>" alt="">
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>

    <input type="text" name="comforts" id="comforts" placeholder="Tags">

    <input type="hidden" name="id" value="<?php echo e($apartment->id); ?>">
    <input type="hidden" name="delete" id="delete">
    <input type="hidden" name="_method" value="PUT">

    <?php echo e(csrf_field()); ?>


    <button class="btn btn-success">Save</button>
</form>

<script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
<script>
    //    CKEDITOR.replace( 'apartmant-ckeditor' );

    var tagsdata = [];
    tagsdata.push({id: 1, name: "Free parking", value: "fdsg"});
    tagsdata.push({id: 2, name: "Free Wi-Fi"});
    tagsdata.push({id: 3, name: "Family rooms"});
    tagsdata.push({id: 4, name: "Pets allowed"});
    tagsdata.push({id: 5, name: "Non-smoking rooms"});
    tagsdata.push({id: 6, name: "Restaurant"});
    tagsdata.push({id: 7, name: "Bar"});

    $("#comforts").sTags({
        data: tagsdata,
        defaultData: [<?php echo e($apartment->comforts); ?>],
    });
</script>