<table class="table table-bordered">
    <thead>
    <tr>
        <th>Book start</th>
        <th>Book end</th>
        <th>Apartment</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <?php if($books): ?>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(date('d-m-Y', strtotime($book->book_start))); ?></td>
                <td><?php echo e(date('d-m-Y', strtotime($book->book_end))); ?></td>
                <?php if($book->apartment): ?>
                    <td>
                        <a href="<?php echo e(route('show.apart', ['alias' => $book->apartment['alias']])); ?>"><?php echo e($book->apartment['title']); ?></a>
                    </td>
                <?php else: ?>
                    <td>Null</td>
                <?php endif; ?>
                <td>
                    <form action="<?php echo e(route("book.destroy", ['book' => $book->id])); ?>" method="post" style="display: inline-block;">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="4" style="text-align: center">Empty!</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>