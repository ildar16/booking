@extends(config('settings.theme').'.layouts.admin')

@section('content')
    {!! $content !!}
@endsection

@section('footer')
    {!! $footer !!}
@endsection