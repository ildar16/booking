<footer>
    <div class="wrapper footer">
        <ul>
            <li class="links">
                <ul>
                    <li><a href="#">About</a></li>
                </ul>
            </li>

            <li class="links">
                <ul>
                    <li><a href="#">Appartements</a></li>
                </ul>
            </li>

            <li class="links">
                <ul>
                    <li><a href="#">New York</a></li>
                </ul>
            </li>

        </ul>
    </div>

    <div class="copyrights wrapper">
        Copyright © 2019
    </div>
</footer>