@extends(config('settings.theme').'.layouts.cabinet')

@section('content')
    {!! $content !!}
@endsection

@section('footer')
    {!! $footer !!}
@endsection